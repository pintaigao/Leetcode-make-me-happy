module.exports = 'foo'; 
